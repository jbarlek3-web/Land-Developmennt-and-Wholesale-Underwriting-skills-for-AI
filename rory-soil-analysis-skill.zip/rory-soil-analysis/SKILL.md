---
name: rory-soil-analysis
description: Certified soil scientist and USDA NRCS specialist skill for the Shadow Intelligence Platform's Rory app. Analyzes USDA/NRCS soil characteristics, productivity, drainage, and development constraints for a parcel or surrounding area using SSURGO/Web Soil Survey data. Use when running soil analysis, reviewing farmland productivity, drainage or hydric soil review, pasture/crop suitability, development soil constraints, or generating soil PDF reports inside Rory's Feasibility → Soil Analysis tab.
---

# Rory Soil Analysis Skill

Analyzes USDA NRCS soil characteristics for a subject property. Integrated into Rory's Feasibility → Soil Analysis tab with DB persistence and PDF export.

## Inputs

| Field | Type | Required | Notes |
|---|---|---|---|
| `propertyId` | number | Optional | Links result to parcel record for persistence |
| `parcelId` | string | Optional | APN or parcel identifier |
| `address` | string | Yes | Full property address |
| `county` | string | Optional | County name |
| `state` | string | Optional | State abbreviation |
| `acreage` | number | Yes | Total parcel acreage |
| `landType` | enum | Yes | agricultural / timber / residential / recreational / mixed / commercial / unknown |
| `sections` | array | Optional | Subset of sections to return (defaults to all 7) |
| `userNotes` | string | Optional | Additional context for the LLM |

## Available Sections

All 7 sections are returned by default:
- `map_unit_summary` — soil map units with capability class, drainage, hydric, flooding, prime farmland, texture, pH, OM%, AWC
- `productivity_metrics` — NCCPI score, crop yields, pasture capability, timber site index, erosion risk, K factor
- `drainage_summary` — overall drainage, tile drainage recommendation, wetland potential, hydric soil %
- `limitations` — each limitation with severity (Slight/Moderate/Severe), affected %, dev/ag impact
- `conservation_data` — HEL %, T factor, wind erodibility group
- `land_use_verdict` — suitability ratings (Excellent/Good/Fair/Poor/Unsuitable) for agriculture, timber, residential, recreational
- `summary` — executive narrative

## LLM System Prompt

```
You are Rory's soil analysis specialist — a certified soil scientist and USDA NRCS specialist.

Your job is to analyze USDA NRCS soil characteristics for a subject property using:
- USDA Web Soil Survey (websoilsurvey.sc.egov.usda.gov)
- SSURGO database
- NRCS references
- County or area soil survey sources when parcel-level detail is unavailable

Operating rules:
1. Prefer exact parcel or immediate surrounding map units.
2. If exact parcel-level soil boundaries are not available, use the nearest supportable
   area and lower data_confidence.
3. Never fabricate survey values. Use null for unavailable fields.
4. Separate hard facts from inference — note when values are estimated.
5. Flag major red flags clearly: hydric soils, flooding, severe limitations, poor drainage,
   high erosion risk, low development suitability.
6. Produce an executive land_use_verdict covering: agricultural, timber,
   residential/development, and recreational suitability.
7. Return only valid JSON matching the provided schema exactly.
```

## Output Schema

### `map_unit_summary[]`
Each map unit: `map_unit_name`, `map_unit_symbol`, `pct_of_area`, `capability_class`,
`drainage_class`, `hydric` (Yes/No/Partially), `flooding_frequency`, `prime_farmland`,
`texture`, `organic_matter_pct`, `ph`, `available_water_capacity`

### `productivity_metrics`
`weighted_productivity_index`, `nccpi_score`, `corn_yield_potential_bu_acre`,
`soybean_yield_potential_bu_acre`, `hay_yield_potential_tons_acre`, `pasture_capability`,
`timber_site_index`, `erosion_risk`, `k_factor`

### `drainage_summary`
`overall_drainage`, `tile_drainage_recommended` (Yes/No/Already likely tiled),
`wetland_potential` (High/Moderate/Low/Negligible), `hydric_soil_pct`

### `limitations[]`
Each: `limitation`, `severity` (Slight/Moderate/Severe), `affected_pct`,
`impact_on_development`, `impact_on_agriculture`

### `conservation_data`
`highly_erodible_land_pct`, `t_factor_avg`, `wind_erodibility_group`

### `land_use_verdict`
Four categories — `agriculture`, `timber`, `residential_development`, `recreational` —
each with `suitability` (Excellent/Good/Fair/Poor/Unsuitable) and `rationale`

### Top-level fields
`data_confidence` (High/Medium/Low), `source`, `survey_area`, `summary`, `notes`

## Operating Rules

- Prefer exact parcel or immediate surrounding map units.
- If exact parcel-level soil boundaries are unavailable, use the nearest supportable area and lower `data_confidence`.
- Never fabricate survey values — use `null` for unavailable fields.
- Distinguish observed facts from inference.
- Flag red flags clearly: hydric soils, flooding, severe limitations, poor drainage, high erosion risk, low development suitability.

## DB Persistence

After running, the procedure stores `soilAnalysisResult` (full JSON) on the `fieldProperties` record. Result reloads automatically on revisit.

## PDF Export

Call `trpc.field.soilAnalysisPDF` with `{ propertyId }`. Returns `{ url }` — open in new tab.

Report sections: Land Use Verdict → Map Units → Productivity Metrics → Drainage Summary → Limitations → Conservation Data → Notes.

## Data Confidence Guidance

When `data_confidence` is **Low**, the analysis used county-level or regional data rather than parcel-specific SSURGO boundaries. Recommend a physical soil survey or perc test before making development decisions.
