---
name: rory-timber-valuation
description: Certified forester and timber appraiser skill for the Shadow Intelligence Platform's Rory app. Performs a comprehensive timber stand inventory, harvest economics analysis, and Maximum Allowable Offer (MAO) calculation for timberland acquisitions. Use when running timber valuation, calculating MAO for rural/timberland deals, or generating timber PDF reports inside Rory's Feasibility → Financials tab.
---

# Rory Timber Valuation Skill

Performs a full timber stand inventory and MAO calculation for a rural property. Integrated into Rory's Feasibility → Financials tab with DB persistence and PDF export.

## Inputs

| Field | Type | Required | Notes |
|---|---|---|---|
| `propertyId` | number | Yes | Links result to the parcel record |
| `mao_method` | enum | Yes | See MAO Methods below |
| `target_profit` | number | Yes | Minimum acceptable profit ($) |
| `total_deal_costs` | number | Yes | Closing, legal, carrying costs ($) |
| `timber_confidence_factor` | number | Immediate Harvest only | 0–1, overrides default confidence |
| `discount_rate` | number | Buy and Hold only | Decimal (e.g. 0.12 = 12%) |
| `years_to_merchantable` | number | Buy and Hold only | Years until sawtimber maturity |
| `recreation_market_value` | number | Recreation Blend only | Comparable recreation land value ($) |

## MAO Methods

```
export const timberMaoMethodOptions = [
  { label: "Conservative",      value: "conservative"      },  // NTV × 0.65
  { label: "Balanced",          value: "balanced"          },  // NTV × 0.80
  { label: "Aggressive",        value: "aggressive"        },  // NTV × 0.90
  { label: "Immediate Harvest", value: "immediate_harvest" },  // NTV × confidence_factor
  { label: "Buy and Hold",      value: "buy_and_hold"      },  // PV(future NTV) via DCF
  { label: "Recreation Blend",  value: "recreation_blend"  },  // max(rec_value, BLV + risk-adj NTV)
];
```

### Conditional UI Fields

- **Always show:** `mao_method`, `target_profit`, `total_deal_costs`
- **`immediate_harvest` only:** `timber_confidence_factor`
- **`buy_and_hold` only:** `discount_rate`, `years_to_merchantable`
- **`recreation_blend` only:** `recreation_market_value`

## MAO Formulas

| Method | Formula |
|---|---|
| Conservative | `MAO = BLV + (NTV × 0.65) − Costs − Profit` |
| Balanced | `MAO = BLV + (NTV × 0.80) − Costs − Profit` |
| Aggressive | `MAO = BLV + (NTV × 0.90) − Costs − Profit` |
| Immediate Harvest | `MAO = BLV + (NTV × confidence_factor) − Costs − Profit` |
| Buy and Hold | `MAO = BLV + PV(Future Timber, rate, years) − Costs − Profit` |
| Recreation Blend | `MAO = max(rec_market_value, BLV + risk-adj NTV) − Costs − Profit` |

**Key terms:**
- **BLV** — Bare Land Value (land without standing timber)
- **NTV** — Net Timber Value (gross value minus harvest and haul costs)
- **PV** — Present Value via DCF discounting

## LLM System Prompt

```
You are a certified forester and timber appraiser with expertise in regional timber markets
across the US South, Pacific Northwest, Lake States, and Northeast. Perform a comprehensive
timber stand inventory and valuation analysis for the provided property.

Using USDA Forest Service FIA data, state forestry commission timber price reports, nearby
active saw mills and pulp mills (within 50-75 miles), satellite imagery forest cover type,
and regional logging contractor rates, estimate the timber stand inventory and current
harvest value.

Return ONLY valid JSON matching the schema exactly. Use null for unavailable numeric fields.
```

## Output Schema (5 top-level sections)

### `stand_inventory`
`dominant_species`, `secondary_species`, `species_mix_description`, `rotation_stage`,
`estimated_age_range`, `basal_area_sq_ft_per_acre`, `trees_per_acre`, `canopy_cover_pct`,
`stand_condition` (Excellent/Good/Fair/Poor), `site_productivity` (High/Medium/Low),
`site_index`, `stocking_level` (Overstocked/Well-stocked/Understocked/Open)

### `volume_estimates`
Per-acre and total tons for: `pulpwood`, `chip_n_saw`, `sawtimber`, `total_merchantable`.
Also: `product_class_mix_pct`, `volume_confidence` (High/Medium/Low), `volume_notes`

### `mill_pricing`
`nearest_mills[]` (name, location, distance_miles, products_accepted, mill_type),
prices per ton for pulpwood / chip-n-saw / sawtimber / hardwood variants,
`price_trend` (Rising/Stable/Declining), `price_data_source`, `price_as_of`

### `harvest_economics`
`logging_cost_per_ton`, `haul_cost_per_ton`, `net_stumpage_pulpwood/chip_n_saw/sawtimber`,
`total_logging_cost`, `total_haul_cost`, `harvest_timing_recommendation`, `contractor_notes`

### `valuation_model`
`total_gross_timber_value`, `total_harvest_costs`, `total_haul_costs`, `net_timber_value`,
`bare_land_value_per_acre`, `bare_land_value_total`, `total_property_value`,
`dcf_analysis` (years_to_merchantable, projected_sawtimber_value, discount_rate_used, present_value_timber)

Plus: `data_confidence` (High/Medium/Low), `notes`

## DB Persistence

After running, the procedure stores on the `fieldProperties` record:
- `timberValuationResult` — full LLM JSON
- `maoCalculation` — MAO inputs, formula, result
- `maoMethod` — selected method
- `maxAllowableOffer` — final MAO dollar value

## PDF Export

Call `trpc.field.timberValuationPDF` with `{ propertyId }`. Returns `{ url }` — open in new tab.

Report sections: MAO Banner → Stand Inventory → Volume Estimates → Mill Pricing → Harvest Economics → Valuation Model → Notes.

## Data Confidence Guidance

When `data_confidence` is **Low**, prefer the **Conservative** method and verify mill prices with a local timber broker before submitting an offer.
